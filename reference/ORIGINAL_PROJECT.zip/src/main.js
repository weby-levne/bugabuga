import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js";

const sceneHost = document.querySelector("#scene");
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9fc3d0);
scene.fog = new THREE.Fog(0x9fc3d0, 65, 230);
const camera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, .1, 500);
const renderer = new THREE.WebGLRenderer({antialias:true, powerPreference:"high-performance"});
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.7));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
sceneHost.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xdceeff, 0x526047, 2.1));
const sun = new THREE.DirectionalLight(0xfff2d7, 2.4);
sun.position.set(-35,55,25); sun.castShadow=true; sun.shadow.mapSize.set(1024,1024);
scene.add(sun);

const mat=(color,roughness=.8,metalness=0)=>new THREE.MeshStandardMaterial({color,roughness,metalness});
const asphalt=mat(0x343b40), grass=mat(0x52744b), lineMat=mat(0xe8e4cf), tireMat=mat(0x111416), glassMat=new THREE.MeshStandardMaterial({color:0x7ca6b2,roughness:.25,metalness:.2,transparent:true,opacity:.65});
const ground=new THREE.Mesh(new THREE.PlaneGeometry(500,500),grass); ground.rotation.x=-Math.PI/2; ground.position.y=-.08; ground.receiveShadow=true; scene.add(ground);
const road=new THREE.Mesh(new THREE.PlaneGeometry(15,360),asphalt); road.rotation.x=-Math.PI/2; road.position.set(0,0,-100); road.receiveShadow=true; scene.add(road);
for(let z=70;z>-270;z-=12){const dash=new THREE.Mesh(new THREE.PlaneGeometry(.18,5),lineMat);dash.rotation.x=-Math.PI/2;dash.position.set(0,.015,z);scene.add(dash)}
for(const x of [-7.2,7.2]){const edge=new THREE.Mesh(new THREE.PlaneGeometry(.16,360),lineMat);edge.rotation.x=-Math.PI/2;edge.position.set(x,.02,-100);scene.add(edge)}
// Low-cost roadside scenery
for(let i=0;i<48;i++){const z=60-i*7.2;for(const side of [-1,1]){const x=side*(12+(i%3)*2);const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.16,.22,2,6),mat(0x584330));trunk.position.set(x,1,z);trunk.castShadow=true;scene.add(trunk);const crown=new THREE.Mesh(new THREE.ConeGeometry(1.45,3.5,7),mat(i%2?0x315c3d:0x416b45));crown.position.set(x,3.3,z);crown.castShadow=true;scene.add(crown)}}
const car=new THREE.Group();scene.add(car);
const body=new THREE.Mesh(new THREE.BoxGeometry(2.05,.62,4.25),mat(0x176b82,.35,.45));body.position.y=.83;body.castShadow=true;car.add(body);
const hood=new THREE.Mesh(new THREE.BoxGeometry(1.9,.25,1.15),mat(0x1c829b,.32,.4));hood.position.set(0,1.13,-1.35);car.add(hood);
const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.62,.78,1.85),mat(0x1b596a,.3,.3));cabin.position.set(0,1.48,.35);cabin.castShadow=true;car.add(cabin);
const windshield=new THREE.Mesh(new THREE.BoxGeometry(1.48,.55,.05),glassMat);windshield.position.set(0,1.52,-.59);car.add(windshield);
const wheelMeshes=[];
for(const x of [-1.02,1.02])for(const z of [-1.35,1.35]){const w=new THREE.Mesh(new THREE.CylinderGeometry(.39,.39,.22,16),tireMat);w.rotation.z=Math.PI/2;w.position.set(x,.48,z);w.castShadow=true;car.add(w);wheelMeshes.push(w)}
for(const x of [-.72,.72]){const lamp=new THREE.Mesh(new THREE.BoxGeometry(.42,.15,.08),mat(0xfff1bd,.3));lamp.position.set(x,.9,-2.14);car.add(lamp)}
car.position.set(0,0,8);

const state={speed:0,gear:"N",clutch:1,gas:0,brake:0,steer:0,rpm:800,engine:true,paused:true,camera:"cockpit",mode:"free",lesson:0,heading:0};
const gears={R:-3.2, N:0, 1:3.6,2:6.4,3:9.5,4:13,5:16.5,6:20};
const el=id=>document.getElementById(id);
function msg(t){el("message").textContent=t}
function updateHUD(){el("speed").textContent=Math.round(Math.abs(state.speed)*3.6);el("gearReadout").textContent=state.gear;el("clutchPct").textContent=Math.round(state.clutch*100)+"%";el("clutchFill").style.height=(state.clutch*100)+"%";el("rpm").textContent=Math.round(state.rpm)+" RPM";el("engineStatus").parentElement.classList.toggle("stalled",!state.engine);el("statusText").textContent=state.engine?"MOTOR V CHODU":"MOTOR ZHASL";document.querySelectorAll("[data-gear]").forEach(b=>b.classList.toggle("selected",b.dataset.gear===state.gear))}
function setGear(g){if(Math.abs(state.speed)>1.2){msg("Před řazením zpomal.");return}if(state.clutch<.72){msg("Sešlápni spojku až na podlahu.");return}state.gear=g;updateHUD();msg(g==="N"?"Neutrál zařazen.":`Zařazeno ${g}.`)}
document.querySelectorAll("[data-gear]").forEach(b=>b.addEventListener("pointerdown",e=>{e.preventDefault();setGear(b.dataset.gear)}));
function holdButton(button,key){const b=el(button);const down=e=>{e.preventDefault();state[key]=1;b.classList.add("pressed");b.setPointerCapture?.(e.pointerId)};const up=e=>{state[key]=0;b.classList.remove("pressed")};b.addEventListener("pointerdown",down);["pointerup","pointercancel","lostpointercapture"].forEach(ev=>b.addEventListener(ev,up))}
holdButton("gas","gas");holdButton("brake","brake");
const clutchTrack=el("clutchTrack");let clutchPointer=null;
function clutchAt(e){const r=clutchTrack.getBoundingClientRect();const y=Math.max(0,Math.min(1,(e.clientY-r.top)/r.height));state.clutch=y;updateHUD()}
clutchTrack.addEventListener("pointerdown",e=>{e.preventDefault();clutchPointer=e.pointerId;clutchTrack.setPointerCapture(e.pointerId);clutchAt(e)});
clutchTrack.addEventListener("pointermove",e=>{if(e.pointerId===clutchPointer)clutchAt(e)});
["pointerup","pointercancel","lostpointercapture"].forEach(ev=>clutchTrack.addEventListener(ev,()=>{clutchPointer=null}));
const steerRange=el("steerRange");steerRange.addEventListener("input",()=>{state.steer=Number(steerRange.value)/100;el("steering").style.transform=`rotate(${state.steer*115}deg)`});
el("cameraBtn").addEventListener("click",()=>{state.camera=state.camera==="cockpit"?"chase":"cockpit";el("cameraBtn").textContent="KAMERA: "+(state.camera==="cockpit"?"KOKPIT":"ZA AUTEM")});
el("mirrorBtn").addEventListener("click",()=>el("mirror").classList.toggle("hidden"));
el("pauseBtn").addEventListener("click",()=>{state.paused=true;el("pauseOverlay").classList.remove("hidden")});
el("resumeBtn").addEventListener("click",()=>{state.paused=false;el("pauseOverlay").classList.add("hidden")});
el("resetBtn").addEventListener("click",()=>{state.speed=0;state.gear="N";state.clutch=1;state.engine=true;car.position.set(0,0,8);state.heading=0;state.paused=false;el("pauseOverlay").classList.add("hidden");updateHUD();msg("Jízda resetována.")});
el("freeMode").addEventListener("click",()=>{state.mode="free";el("freeMode").classList.add("active");el("schoolMode").classList.remove("active")});
el("schoolMode").addEventListener("click",()=>{state.mode="school";el("schoolMode").classList.add("active");el("freeMode").classList.remove("active")});
el("startBtn").addEventListener("click",()=>{state.paused=false;el("startOverlay").classList.add("hidden");el("lessonPanel").classList.toggle("hidden",state.mode!=="school");msg("Sešlápni spojku, zařaď 1 a pomalu přidávej plyn.")});
const lessons=["Lekce 1: Rozjezd","Lekce 2: Řazení nahoru","Lekce 3: Brzdění a zastavení","Lekce 4: Bezpečná jízda"];
el("lessonBtn").addEventListener("click",()=>{state.lesson=(state.lesson+1)%lessons.length;el("lessonText").textContent=lessons[state.lesson];msg(lessons[state.lesson])});
function resize(){camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,1.7))}
addEventListener("resize",resize);
let last=performance.now();
function animate(now){requestAnimationFrame(animate);const dt=Math.min((now-last)/1000,.04);last=now;
 if(!state.paused){
   const ratio=state.gear==="N"?0:Math.abs(state.speed)/(Math.abs(gears[state.gear]||1)*.28+.6);
   const clutchEngagement=1-state.clutch;
   const inGear=state.gear!=="N";
   const targetRPM=state.engine?800+state.gas*5200+(inGear?clutchEngagement*ratio*1600:0):0;
   state.rpm+=(targetRPM-state.rpm)*Math.min(1,dt*4);
   if(state.engine&&inGear&&state.speed<1.5&&state.gas<.12&&clutchEngagement>.72&&state.rpm<650){state.engine=false;msg("Motor zhasl. Sešlápni spojku a nastartuj znovu.")}
   if(!state.engine&&state.clutch>.9&&state.gas>.25){state.engine=true;state.rpm=900;msg("Motor nastartoval.")}
   let accel=0;
   if(state.engine&&inGear){const desired=state.gas*gears[state.gear]*.16*clutchEngagement;accel=desired-(state.speed*.11);if(state.clutch>.05&&state.clutch<.95&&state.speed<3)accel-=.5*(1-state.clutch)}
   if(state.brake)accel-=state.brake*(1.5+Math.abs(state.speed)*.8);
   if(!state.gas&&!state.brake)accel-=Math.sign(state.speed)*.22;
   state.speed+=accel*dt;state.speed=Math.max(-8,Math.min(45,state.speed));
   state.heading+=state.steer*state.speed*.012*dt;
   car.position.x-=Math.sin(state.heading)*state.speed*dt;car.position.z-=Math.cos(state.heading)*state.speed*dt;
   car.rotation.y=state.heading;car.rotation.z=-state.steer*Math.min(Math.abs(state.speed)/20,.12);
   wheelMeshes.forEach(w=>w.rotation.x+=state.speed*dt*1.7);
   if(car.position.z < -245){car.position.z=30}
   if(Math.abs(car.position.x)>5.7){state.speed*=.985}
 }
 const cockpit=state.camera==="cockpit";
 const targetPos=cockpit?new THREE.Vector3(car.position.x,car.position.y+2.0,car.position.z+0.15):new THREE.Vector3(car.position.x+Math.sin(state.heading)*7,car.position.y+5.5,car.position.z+Math.cos(state.heading)*10);
 const lookAt=cockpit?new THREE.Vector3(car.position.x,car.position.y+1.6,car.position.z-15):new THREE.Vector3(car.position.x,car.position.y+1,car.position.z-5);
 camera.position.lerp(targetPos,.12);camera.lookAt(lookAt);
 updateHUD();renderer.render(scene,camera)}
requestAnimationFrame(animate);
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
