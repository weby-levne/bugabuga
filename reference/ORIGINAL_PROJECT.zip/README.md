# Driving School Simulator

Mobilní webový prototyp 3D manuálního řízení. Projekt je připravený pro GitHub Pages a zabalení do Android aplikace přes Median.co.

## Co prototyp obsahuje
- 3D scénu vytvořenou v Three.js (silnice, okolní stromy a jednoduché vozidlo)
- pohled z kokpitu a pohled za autem
- dotykový pedál spojky s plynulou hodnotou podle svislé pozice prstu
- plyn a brzdu jako dotyková tlačítka
- manuální řazení R, N, 1–6
- volant ovládaný posuvníkem
- zhasnutí motoru při nevhodném zacházení se spojkou
- jednoduchý panel autoškoly a zpětné zrcátko
- základní PWA manifest a service worker

## Spuštění lokálně
Projekt používá ES moduly a Three.js z CDN, proto ho spusť přes lokální webový server, ne otevřením `index.html` jako souboru.

Například:
```bash
python -m http.server 8000
```
Pak otevři `http://localhost:8000`.

## Publikování přes GitHub Pages
1. Na GitHubu vytvoř nový veřejný repozitář `driving-school-simulator`.
2. Nahraj obsah ZIPu (složky `src`, soubory `index.html`, `style.css`, `manifest.webmanifest`, `sw.js`, `README.md`) do kořene repozitáře.
3. V repozitáři otevři **Settings → Pages**.
4. V části **Build and deployment** vyber **Deploy from a branch**.
5. Vyber větev `main` a složku `/ (root)`, pak Save.
6. Počkej na dokončení publikování. Adresa bude obvykle `https://TVUJ-UCET.github.io/driving-school-simulator/`.

## Zabalení v Median.co
1. Přihlas se do Median.co a vytvoř nový projekt / aplikaci.
2. Jako webovou adresu zadej URL publikovanou přes GitHub Pages.
3. Nastav název `Driving School Simulator`.
4. V nastavení aplikace povol orientaci Landscape (na šířku) a fullscreen / immersive režim, pokud ho zvolený plán Median podporuje.
5. Vytvoř Android build podle průvodce Median a otestuj jej na telefonu.

Poznámka: názvy položek a dostupnost funkcí Median se mohou měnit podle verze služby a tarifu. Pro publikování do Google Play mohou být potřeba další účty, podpis aplikace a splnění pravidel Google Play.

## Ovládání
- **Spojka:** dotkni se zeleného pedálu a táhni prstem nahoru/dolů. Hodnota se mění plynule podle pozice prstu v pedálu.
- **Plyn / brzda:** podrž příslušný pedál.
- **Řazení:** spojku sešlápni téměř na 100 %, potom zvol rychlost.
- **Volant:** posuň jezdec doleva nebo doprava.
- **Kamera:** přepíná kokpit / pohled za vozem.
- **Zrcátko:** zobrazí nebo skryje panel zrcátka.

## Důležitá technická poznámka
Toto je první hratelný prototyp, ne hotová realistická autoškola. Fyzika vozidla je zjednodušená a model auta je procedurální 3D objekt. Pro další verzi doporučujeme doplnit skutečný 3D model vozidla, přesnější převodové poměry, spojkovou křivku a simulaci přenosu hmotnosti, kolize, zvuk motoru, provoz a detailní prostředí.
